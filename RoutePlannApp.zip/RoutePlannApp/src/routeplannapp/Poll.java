/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package routeplannapp;

import java.util.Random;

public class Poll {
    private String[] transportModes = {"Bike", "Car", "Train", "Bus", "Walking"}; //declares an array for transport modes.
    private int[] percentage;

    public Poll() {
        generatePollResults();
    }

  
    public void generatePollResults() { //creates the poll
        percentage = new int[transportModes.length];
        int totalVotes = 100;
        Random random = new Random();
        int remainingVotes = totalVotes;

        for (int i = 0; i < transportModes.length; i++) {
            if (i == transportModes.length - 1) {
                percentage[i] = remainingVotes;  //this will assign the rest of the "votes"
            } else {
                percentage[i] = random.nextInt(remainingVotes + 1); //this will select a random number starting from zero for all the topics.
                remainingVotes -= percentage[i];
            }
        }
    }

    public String getPollResults() {
        StringBuilder pollResults = new StringBuilder("Poll Results:\n");
        for (int i = 0; i < transportModes.length; i++) {
            pollResults.append(transportModes[i]).append(": ").append(percentage[i]).append("%\n");
        }
        return pollResults.toString();
    }
}

