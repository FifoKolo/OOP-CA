/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package routeplannapp;

import java.io.Serializable;

/**
 *
 * @author Conno
 */
public class Account implements Serializable{
    public String name;
    public String email;
    public String age;
    public String password;

    public Account(){
        name = new String();
        email = new String();
        age = new String();
        password = new String();
    }
    public Account(String name, String email, String age, String password) {
        this.name = name;
        this.email = email;
        this.age = age;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDetails() {
        return "Name: " + name + "\nEmail: " + email + "\nAge: " + age;
    }
}
