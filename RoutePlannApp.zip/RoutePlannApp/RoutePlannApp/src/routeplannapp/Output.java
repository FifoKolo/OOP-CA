/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package routeplannapp;

/**
 *
 * @author Conno
 */
public class Output {
    private String start;
    private String end;
    private String time;
    private int co2;

    public Output(String start, String end, String time, int co2) {
        this.start = start;
        this.end = end;
        this.time = time;
        this.co2 = co2;
    }

    public String output() {
        return "From " + start + " to " + end + "\nEstimated time: " + time + " minutes\nCO2 emissions: " + co2 + " grams";
    }
}
