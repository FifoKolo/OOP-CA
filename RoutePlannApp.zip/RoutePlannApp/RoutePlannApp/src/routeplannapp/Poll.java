/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package routeplannapp;


import java.io.*;

/**
 *
 * @author Connor
 */

public class Poll implements Serializable {
    //private static final long serialVersionUID = 1L;
    
    private int bikeVotes;
    private int carVotes;
    private int trainVotes;
    private int busVotes;
    private int walkingVotes;

    public Poll() {
        // Initialize all votes to 0
        bikeVotes = carVotes = trainVotes = busVotes = walkingVotes = 0;
    }

    public void vote(String transportType) {
        switch (transportType.toLowerCase()) {
            case "bike":
                bikeVotes++;
                break;
            case "car":
                carVotes++;
                break;
            case "train":
                trainVotes++;
                break;
            case "bus":
                busVotes++;
                break;
            case "walking":
                walkingVotes++;
                break;
        }
    }

    public String getPollResults() {
        return "Poll Results:\n" +
               "Bike: " + bikeVotes + " votes\n" +
               "Car: " + carVotes + " votes\n" +
               "Train: " + trainVotes + " votes\n" +
               "Bus: " + busVotes + " votes\n" +
               "Walking: " + walkingVotes + " votes\n";
    }
    
    public void save() { //Seralizes and saves poll while using the try-catch method to handle potential IOExceptions and report errors.
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("poll.dat"))) {
            oos.writeObject(this);
        } catch (IOException e) {
            System.err.println("Error saving poll: " + e.getMessage());
        }
    }
    
    public static Poll load() { //load a serialized Poll object from "poll.dat" file;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("poll.dat"))) {
            return (Poll) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("No existing poll data, creating new poll");
            return new Poll();
        }
    }
    
    public void reset() {
    bikeVotes = 0;
    carVotes = 0;
    trainVotes = 0;
    busVotes = 0;
    walkingVotes = 0;
    save(); 
}

}




  


